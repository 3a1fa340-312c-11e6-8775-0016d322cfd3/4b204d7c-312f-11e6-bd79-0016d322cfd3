function ShowTopBlock()
{
	showmenu(menuindex++);
}


function Showblank()
{
document.write('<TR>');
document.write('<TD><IMG WIDTH=2 HEIGHT="1" SRC="images/blank.gif"></TD>');
document.write('<TD><IMG WIDTH="6" HEIGHT="1" SRC="images/blank.gif"></TD>');
document.write('<TD><IMG WIDTH=3 HEIGHT="1" SRC="images/blank.gif"></TD>');
document.write('<TD><IMG WIDTH="540" HEIGHT="1" SRC="images/blank.gif"></TD>');
document.write('<TD><IMG WIDTH="1" HEIGHT="1" SRC="images/blank.gif"></TD>');
document.write('<TD><IMG WIDTH=8 HEIGHT="1" SRC="images/blank.gif"></TD>');
document.write('<TD><IMG WIDTH=2 HEIGHT="1" SRC="images/blank.gif"></TD>');
document.write('</TR>');
}